/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

/**
 *
 * @author bihas
 */

public class SessionManager {
    public static boolean isAdminLoggedIn = false;
    public static boolean isStudentLoggedIn = false;
    public static String loggedInStudentId = null; 
}
